/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.anothercam;

import java.util.ArrayList;

/**
 *
 * @author Halogen
 */
public class UnregisterList {
        public static ArrayList<User> unregisterListUser = new ArrayList<User>();
        public static ArrayList<Integer> unregisterListCamp = new ArrayList<Integer>();
    /**
    * Adds an Unregister Object to the ArrayList of Unregister tabulations in the application.
    * @param unregister 
    * @param campID campID to remove the unregistered user from  
    *                The validation is already done before the method is called.
    */
    /*
    public void addUnregisterToList(User unregister, int campID){
        unregisterListUser.add(unregister);
        unregisterListCamp.add(campID);
    }
    */
    /**
    * Adds an Unregister Object to the ArrayList of Unregister tabulations in the application.
    * @param unregister This 
    * @param campID This  
    *                The validation is already done before the method is called.
    */
    /*
    public void removeStaffToList(User unregister, int campID){

    }
    */
}
